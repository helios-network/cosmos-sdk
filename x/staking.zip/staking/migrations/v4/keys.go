package v4

const (
	// ModuleName is the name of the module
	ModuleName = "staking"
)

var ParamsKey = []byte{0x51} // prefix for parameters for module x/staking
