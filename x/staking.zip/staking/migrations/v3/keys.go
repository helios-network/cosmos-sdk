package v3

const (
	// ModuleName is the name of the module
	ModuleName = "staking"
)
